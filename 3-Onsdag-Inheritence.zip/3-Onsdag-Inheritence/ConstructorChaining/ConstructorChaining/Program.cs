﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorChaining
{
    public class Dyr
    {
        public Dyr()
        {
            Console.WriteLine("\n\t Default Constructor of Dyr Class");
        }
        public Dyr(string lyd) : this()
        {
            Console.WriteLine("\n\t Lyd => \t" +lyd);
        }
    }
    public class Kat : Dyr
    {
        public Kat() : base("Miyoon Miyoon")
        {
            Console.WriteLine("\n\t Default Constructor of KAT Class");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Kat k = new Kat();
            Console.ReadKey();
        }
    }
}
