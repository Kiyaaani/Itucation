﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritenceEx
{
    public class A
    {
        int x; // by default all members of a class are private
        public int px;
        protected int pt;
        internal int i;
        protected internal int pti; // protected OR internal
        private protected int prpt;
        public void ShowA()
        {
            //ptDownWards = 5;  can't access upwards
            Console.WriteLine("\n\t SHOW AAAAA");
        }
    }
    public class B : A
    {
        protected int ptDownWards;
        public void ShowB()
        {
            //x = 7;  can't access
            px = 7;
            pt = 9;
            i = 8;
            prpt = 3;
            Console.WriteLine("\n\t SHOW BBBBB");
        }
        protected void PtShowB()
        {
            Console.WriteLine("\n\t SHOW PTPTPTBBBBB run in C");
        }
    }
    public class C : B //, A   multiple class inheretence not allowed
    {
        public void ShowC()
        {
            PtShowB();
            pt = 5;  i = 3;
            Console.WriteLine("\n\t Show CCCCC");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            A a = new A();
            a.px = 9;
            //a.pt=2;  not visible out side the inheritence Area
            C c = new C();
            c.i = 4;
            c.pti = 7;
            
            c.ShowA();
            c.ShowB();
            c.ShowC();

            Console.ReadKey();
        }
    }
}
