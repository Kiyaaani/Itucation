﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InheritenceEx;

namespace AnotherProject
{
    public class D : C
    {
        public void ShowD()
        {
            px = 2; pt = 9; //i= 5; visible within namespace 
            pti = 1; ptDownWards = 8; //prpt = 1; 
            Console.WriteLine("\n\t Show DDDDD");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            D d = new D();
            d.px = 5; // only public members visible here
            d.ShowA();d.ShowB();
            d.ShowC(); d.ShowD();

            Console.ReadKey();
        }
    }
}
