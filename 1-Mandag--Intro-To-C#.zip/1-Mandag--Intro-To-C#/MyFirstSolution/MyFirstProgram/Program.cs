﻿using System;


namespace MyFirstProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            int x,y,z; string navn; double avg;
            Console.WriteLine("\n\t Hej, Please enter your name");
            navn = Console.ReadLine();
            //Console.WriteLine("\n\t Hej, "+ navn);

            Console.WriteLine("\n\t Please enter a number");
            x=int.Parse(Console.ReadLine());

            Console.WriteLine("\n\t Please enter another number");
            y = int.Parse(Console.ReadLine());
            z = x + y;

            Console.WriteLine("\n\t Hej, \t"+navn 
                                 + "\n\t x = \t" + x
                                 + "\n\t y = \t" + y
                                 +"\n\t sum = \t" + z );

            Console.WriteLine("\n\t Hej, \t {0}" 
                     + "\n\t x = \t {1}" 
                     + "\n\t y = \t {2}" 
                     + "\n\t sum = \t {3}"
                     , navn, x, y, z);

            Console.WriteLine($"\n\t Hej, \t {navn} \n\t x = \t {x}"
                     + $"\n\t y = \t {y} \n\t sum = \t {z}");

            Console.ReadKey();
        }
    }
}
