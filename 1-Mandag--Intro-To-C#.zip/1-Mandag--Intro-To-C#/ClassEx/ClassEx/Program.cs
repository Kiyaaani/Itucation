﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEx
{
    class Customer
    {
        string navn;
        public void Info(string n)
        {
            navn = n;
        }
        public void Skrive()
        {
            Console.WriteLine("\n\t"+navn);
        }
    }
        class Program
    {
        static void Main(string[] args)
        {
            int x;
            Customer kunde = new Customer();
            kunde.Info("Mark");
            kunde.Skrive();
            Console.ReadKey();
        }
    }

}
