﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelEx
{
    public class Person
    {
        public string Name { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //--- Parallel For Loop------------
            //for (int i = 0; i < 100; i++)
            //{
            //    Console.WriteLine("\n\t"+i);
            //    Thread.Sleep(1000);
            //}
            //Parallel.For(0, 100, (i) =>
            //{
            //    Console.WriteLine("\n\t" + i);
            //    Thread.Sleep(1000);
            //}
            //);
            //---------------------Parallel Foreach--------------------
            int[] A = { 34,45,44,22,55,66,77,88,99,98,87,76,65,54,43,32,11,13,23,34,6,7,78,79};
            //foreach (var item in A)
            //{
            //    Console.WriteLine("\n\t" + item);
            //    Thread.Sleep(1000);
            //}
            //Console.WriteLine("\n-------------------------\n");
            //Parallel.ForEach(A, (item) =>
            //{
            //    Console.WriteLine("\n\t" + item);
            //    Thread.Sleep(1000);
            //});
            //--------PLINQ------------->Parallel LINQ----------------
            IEnumerable<int> result = from item in A
                                      .AsParallel()
                                      .AsOrdered()
                                      select item;
            //foreach (var a in result)
            //{
            //    Console.Write("\t" + a);
            //}
            //Console.WriteLine("\n-------------------------\n");
            //Parallel.ForEach(result, (a)=>
            //    {
            //        Console.Write("\t" + a);
            //        Thread.Sleep(1000);
            //    });

            Person[] Personer = new Person[]
                {
                    new Person{Name="John", City= "London"},
                    new Person{Name="Jens", City= "Copenhagen"},
                    new Person{Name="Johan", City= "Odense"},
                    new Person{Name="Jonas", City= "Viby"},
                    new Person{Name="Julius", City= "Berlin"},
                    new Person{Name="Jaffery", City= "London"},
                    new Person{Name="Jasmin", City= "Oslo"},
                    new Person{Name="Jonny", City= "Roskilde"}
                };

            IEnumerable<Person> PLINQResult = from p in Personer
                                              .AsParallel()
                                              //.AsOrdered()
                                              orderby p.City
                                              select p;

            foreach (var person in PLINQResult)
            {
                Console.WriteLine($"\n\t {person.Name}\t{person.City}");
            }
            Console.ReadKey();
        }
    }
}
