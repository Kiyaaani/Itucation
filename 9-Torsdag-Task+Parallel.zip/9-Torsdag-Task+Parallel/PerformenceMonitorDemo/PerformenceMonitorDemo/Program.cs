﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformenceMonitorDemo
{
    class Program
    {
        static void PrintManyStars()
        {
            
            for (int i = 0; i < 100000; i++)
            {
                Console.Write(" * ");
            }
        }
        static void Main(string[] args)
        {
            //PrintManyStars();
            Parallel.For(0, 50, x => PrintManyStars());
            Console.ReadKey();
        }
    }
}
