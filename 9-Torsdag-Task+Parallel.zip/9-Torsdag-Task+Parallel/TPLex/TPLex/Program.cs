﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPLex
{
    class Program
    {
        static void AnyMethod()
        {
            for (int i = 1; i < 11; i++)
            {
                Console.WriteLine("\n\t ---> \t"+i);
                Thread.Sleep(500);
            }
        }
        static void Main(string[] args)
        {
            //--------Thread pool----------
            //ThreadPool.QueueUserWorkItem(
            //    (k) =>
            //    {
            //        Console.WriteLine("\n\t Work Item from thread pool");
            //    });
            //-----------TASK------------------------------------------------------

            // 4-ways to declare or define a task 
            //---1----
            //Task T1 = new Task(AnyMethod);
            //T1.Start(); // start() is only in this case
            ////T1.Join(); Join() with thread but wait() with task
            ////------2-----
            //Task T2 = Task.Run(new Action(AnyMethod));
            ////-----3--------
            //Task T3 = Task.Run(AnyMethod);
            ////-----4-------
            //Task T4 = Task.Factory.StartNew(AnyMethod);

            //---------------Task with return type-----------------------------------
            //Task<int> T5 = Task.Run(
            //    () =>
            //    {
            //        return 6;
            //    });

            //Task<int> T6 = Task.Run(
            //    () =>
            //    {
            //        return 7;
            //    });
            //Console.WriteLine($"\n\t T5 + T6 = {T5.Result+T6.Result}");

            //---------------Continue With------------------------------------------
            // Task<int> T7 = Task.Run(
            //     () =>
            //     {return 5; }
            //     ).ContinueWith(
            //     (i)=>
            //     {
            //         return 8 * i.Result;
            //     }
            //     ).ContinueWith(
            //     (k) =>
            //     {
            //         return (k.Result / 2);
            //     }
            //     );
            // Console.WriteLine("\n\t T7.Result "+T7.Result);
            // //T7.ContinueWith(
            // //    (s) =>
            // //    {
            // //        return s.Result * 30;
            // //    }
            // //    );
            //T7= T7.ContinueWith(
            //     (s) =>
            //     {
            //         return s.Result * 30;
            //     }
            //     );
            // Console.WriteLine("\n\t T7.Result " + T7.Result);
            //------------------- Copmleted successfully Of Failure--------------------------
            Task<int> T = Task.Run(
                () =>
                {
                    int z = 10;
                    if (z==10)
                    {
                        Console.WriteLine("\n\t z = "+z/0);
                        
                    }
                    return z;
                }
                );
            T.ContinueWith(
                (LavetArbejde)=>
                {
                    int d = LavetArbejde.Result * 2;
                    Console.WriteLine("\n\t Task Completed\t"+d);
                }, TaskContinuationOptions.OnlyOnRanToCompletion
                );
            T.ContinueWith(
               (LavetArbejde) =>
               {
                   
                   Console.WriteLine("\n\t Task failed" );
                   //do something alternative
               }, TaskContinuationOptions.OnlyOnFaulted
               );

            Console.ReadKey();
        }
        
    }
}
