﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncAwaitEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //JustAMethod(); // gå for hurtigt 
            //SlowMethod(); // main waiting
             Task<string> T11 = DownLoadPageContent(); // not waiting for Result
            //Console.WriteLine("\n\t"+ DownLoadPageContent().Result); // waiting Result
            //Console.WriteLine("\n\t" + T11.Result);
            Console.WriteLine("\n\t Main Method was waiting for slow Method");

            Console.WriteLine("\n\t" + T11.Result);
            Console.ReadKey();
        }
        static async void JustAMethod()
        {
           await Task.Run(new Action(SlowMethod));
        }
        static void SlowMethod()
        {
            Thread.Sleep(15000);
            Console.WriteLine("\n\t Slow Method");
        }
        static async Task<string> DownLoadPageContent()
        {
            HttpClient clt = new HttpClient();
            string result = await clt.GetStringAsync("http://www.dmi.dk");
            Thread.Sleep(10000);
            return result;
        }
    }
}
