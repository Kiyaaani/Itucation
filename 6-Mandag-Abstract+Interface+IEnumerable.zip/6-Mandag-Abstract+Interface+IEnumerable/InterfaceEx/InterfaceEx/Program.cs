﻿using System;

namespace InterfaceEx
{
    /*
     * 1- 100% abstract, no need to write key word 'abstract'
     * 2- alway public, no need to write key word 'public'
     * 3- Fields / variables not allowed but properties allowed
     * 4- Methods -> Only Declarations - no Implementations
     * 5- Naming convention --> name starts with 'I'
     */

    interface IA
    {
        //int x; 
        // public int Id { get; set; }
        void ShowIA()
        {
            Console.WriteLine("\n\t Within Interface");
        }
    }
    interface IB : IA
    {
        void ShowIB();
    }
    public class C
    {
        public void ShowC()
        {
            Console.WriteLine("\n\t Show method in class CCCCCC");
        }
    }
    public class D
    {

    }
    public class K : C, IA, IB //, D multiple class inhertence not allowed
    {
        //public int Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public void ShowIA()
        {
            //Console.WriteLine("\n\t ShowIA imlemented in Class K");
        }

        public void ShowIB()
        {
            Console.WriteLine("\n\t ShowIB imlemented in Class K");
        }
        public void ShowK()
        {
            Console.WriteLine("\n\t Show Method in class KKKKKKK");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //IA a = new IA();  not allowed
            Console.WriteLine("\n\t------ IA type instance of class KKKKK-------");
            IA iaK = new K();
            iaK.ShowIA();

            Console.WriteLine("\n\t------ IB type instance of class KKKKK-------");
            IB ibK = new K();
            ibK.ShowIA();
            ibK.ShowIB();

            Console.WriteLine("\n\t------ C type instance of class KKKKK-------");
            C cK = new K();
            cK.ShowC();

            Console.WriteLine("\n\t------ K type instance of class KKKKK-------");
            K k = new K();
            k.ShowIA();
            k.ShowIB();
            k.ShowC();
            k.ShowK();

            //Console.ReadKey();
        }
    }
}
