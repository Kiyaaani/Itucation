﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableEx
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> lst = new List<int>();
            lst.Add(11); lst.Add(22); lst.Add(33); lst.Add(44);
            lst.Add(55); lst.Add(66); lst.Add(77); lst.Add(88);
            lst.Add(99);
            Console.WriteLine("\n\t---------------IEnumerable---------------\n");
            IEnumerable<int> enb = (IEnumerable<int>)lst; //type casting
            //foreach (int i in enb)
            //{
            //    Console.WriteLine("\n\t "+i);
            //}
            //ShowUpTo55(enb);
            Console.WriteLine("\n\t---------------IEnumerator---------------\n");
            IEnumerator<int> ent = lst.GetEnumerator();
            //foreach (var item in ent){} can't use it here
            //while (ent.MoveNext())
            //{
            //    Console.WriteLine("\n\t"+ent.Current);
            //}
            ShowUpTo55(ent);
            Console.ReadKey();
        }

        //static void ShowUpTo55(IEnumerable<int> enb)
        //{
        //    foreach (var item in enb)
        //    {
        //        if (item > 55)
        //        {
        //            ShowLastValues(enb);
        //        }
        //        else
        //        {
        //            Console.WriteLine("\n\t -->" + item);
        //        }
        //    }
        //}
        //static void ShowLastValues(IEnumerable<int> enb)
        //{
        //    foreach (var item in enb)
        //    {
        //        Console.WriteLine("\n\t " + item + "<--");
        //    }
        //}

        static void ShowUpTo55(IEnumerator<int> ent)
        {
            while (ent.MoveNext())
            {
                if (ent.Current>55)
                {
                    ShowLastValues(ent);
                }
                else
                {
                    Console.WriteLine("\n\t --->"+ent.Current);
                }
            }
        }
        static void ShowLastValues(IEnumerator<int> ent)
        {
            Console.WriteLine("\n\t" + ent.Current + "<----");
            while (ent.MoveNext())
            {
                Console.WriteLine("\n\t" + ent.Current +"<----");
            }
        }
    }
}
