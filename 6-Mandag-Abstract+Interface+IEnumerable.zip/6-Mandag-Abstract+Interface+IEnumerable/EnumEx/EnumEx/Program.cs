﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumEx
{
    /*
     * 1- Enum is a set of integers constants
     * 2- C# doesn't support string Enum
     * 3- int (index) starts from 0 unless you gi´ve another value
     * 4- Human readable name are suger-coating over these integers
     */
     public enum Country
    {
        Denmark = 123,
        Sverige =233 ,
        Norge =333,
        Finland= 4
    }
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //public int Land { get; set; }
        public Country Land { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Customer[] kunder = new Customer[4];
            //kunder[0] = new Customer() {Id=1, Name="Ove", Land=1 };
            kunder[0] = new Customer() { Id = 1, Name = "Ove", Land = Country.Denmark };
            kunder[1] = new Customer() { Id = 2, Name = "Ole", Land = Country.Finland };
            kunder[2] = new Customer() { Id = 3, Name = "Mia", Land = Country.Norge };
            kunder[3] = new Customer() { Id = 4, Name = "Kim", Land = Country.Sverige };

            //foreach (var kunde in kunder)
            //{
            //    Console.WriteLine($"\n\t Id = {kunde.Id}\t Name = {kunde.Name}\t Land = {kunde.Land}");
            //    //Console.WriteLine($"\n\t Id = {kunde.Id}\t Name = {kunde.Name}\t Land = {GetLandName(kunde.Land)}");
            //}
            Console.WriteLine("\n\t"+(int)Country.Norge);
            Country myLand;
            Enum.TryParse<Country>("333", out myLand);
            Console.WriteLine("\n\t "+myLand);
            Console.ReadKey();
        }
        //static string GetLandName(int x)
        //{
        //    switch (x)
        //    {
        //        case 4: return "Finland";
        //        case 3: return "Sverige";
        //        case 2: return "Norge";
        //        case 1: return "Danmark";
        //        default: return "Ugyldig";
                    
        //    }
        //}
    }
}
