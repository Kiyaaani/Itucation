﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassEx
{
    public class PartTimeEmployee : Employee
    {
        public double HourlyPay { get; set; }
        public double TotalHours { get; set; }
      
        public override double MonthySalary()
        {
            return HourlyPay * TotalHours;
        }
    }
}
