﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassEx
{
    /* 1- You can't create Instance of an abstract class
     * 2- If at least one of the members is abstract, class must be declared abstract
     * 3- Abstract methods can't have implementation
     * 4- Abstract class can have both abstract and non abstract methods
     * 5- Derived class MUST implement abstract methods
     */
    public abstract class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName()
        {
            return FirstName + " " + LastName;
        }
        public abstract double MonthySalary();
    }
}
