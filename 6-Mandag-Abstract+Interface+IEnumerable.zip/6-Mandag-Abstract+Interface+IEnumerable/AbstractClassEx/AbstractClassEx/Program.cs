﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassEx
{   
    class Program
    {
        static void Main(string[] args)
        {
            //Employee e; // = new Employee();   pkt 1.
            Console.WriteLine("\n\t--- Employee type --- Full Time Employee-----");
            Employee fe = new FullTimeEmployee()
            {Id=1, FirstName = "Peter", LastName= "Petersen", AnnualSalary= 400000 };
            //fe.AnnualSalary not visible 
            Console.WriteLine("\n\t" + fe.FullName());
            Console.WriteLine("\n\t" + fe.MonthySalary());
            //fe.SigHej(); // fe will behave like employee not FullTimeEmployee
//-------------------------------------------------------------------------------
            Console.WriteLine("\n\t--- FullTimeEmployee type --- Full Time Employee-----");
            FullTimeEmployee flte = new FullTimeEmployee()
            {Id=2, FirstName="Mark", LastName="Marksen", AnnualSalary=350000 };
            flte.SigHej();
            Console.WriteLine("\n\t" + flte.FullName());
            Console.WriteLine("\n\t" + flte.MonthySalary());
            //------------------------------------------------------------------------
            Console.WriteLine("\n\t--Employee Type PartTime Employee--------------\n");
            Employee pe = new PartTimeEmployee()
            { Id=3, FirstName="Ole", LastName="Olsen", HourlyPay=120, TotalHours=30};
            Console.WriteLine("\n\t" + pe.FullName());
            Console.WriteLine("\n\t" + pe.MonthySalary());
            Console.ReadKey();
        }
    }
}
