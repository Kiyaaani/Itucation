﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassEx
{
    public class FullTimeEmployee : Employee
    {
        public double AnnualSalary { get; set; }
        public override double MonthySalary()
        {
            return AnnualSalary / 12;
        }
        public void SigHej()
        {
            Console.WriteLine("\n\t Full Tid medarbejder siger HEJ ");
        }
    }
}
