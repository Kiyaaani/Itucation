﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesEx
{
    class Person
    {
        //private int Dronning; // by default private

        // public int Vagt { get => Dronning; set => Dronning = value; }

        //private int Dronning;

        //public int Vagt
        //{
        //    get { return Dronning; }
        //    set { Dronning = value; }
        //}
         int Id;
        public int ID
        {
            get { return Id; }
            set {
                if (value<0)
                {
                    Console.WriteLine("\n\t no -ve values please");
                }
                else
                {
                    Id = value;
                }
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            //p.ID = -77;
            p.ID = 55;
            Console.WriteLine("\n\t Id = "+p.ID);
            Console.ReadKey();
        }
    }
}
