﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorEx
{
    public class Customer
    {
        int AcNo; string Name; double Balance;
        /*
         * 1- Constructor is a special method
         * 2- Same name as class name
         * 3- Public, may or may not have parameters
         * 4- No Return Type
         * 5- Overloading allowed
         * 6- It is invoked implicitly, when you create a new instance
         * 7- You can't invoke it explicitly
         */
        public Customer()//Class always have a default constructor (hidden?)
        {
            Console.WriteLine("\n\t default Constructor");
        }

        public Customer(int a, string n, double b)
        {
            AcNo = a;
            Name = n;
            Balance = b;
        }
        public void Saldo()
        {
            Console.WriteLine($"\n\t Acc = {AcNo}\tName = {Name}\t Balance = {Balance}");
        }
        public void Deposit(double amount)
        {
            //Balance = Balance + amount;
            Balance += amount;
        }

        public void WithDraw(double amount)
        {     
            Balance -= amount;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer();
            //c.Customer();
            Customer c2 = new Customer(333, "Mark", 54357);
            c2.Saldo();

            c2.Deposit(3000);
            Console.WriteLine("\n------------After Deposit--------------");
            c2.Saldo();

            c2.WithDraw(33000);
            Console.WriteLine("\n------------After WithDraw--------------");
            c2.Saldo();

            Console.ReadKey();
        }
    }
}
