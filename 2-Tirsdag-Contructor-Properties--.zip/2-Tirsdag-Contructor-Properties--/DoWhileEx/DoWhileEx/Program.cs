﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWhileEx
{
    class Program
    {
        public static void Hej()
        {
            Console.WriteLine("\n\t HEJ");
        }
        static void Main(string[] args)
        {
            //Hej();
            int dagnr;
            do
            {
                Console.WriteLine("Enter 1-7, get day name, enter 0 to stop");
                //dagnr = int.Parse(Console.ReadLine());
                //int.TryParse(Console.ReadLine(), out dagnr);
                dagnr = int.TryParse(Console.ReadLine(), out dagnr) ? dagnr:3;
                switch (dagnr)
                {
                    case 1:
                        Console.WriteLine("\n\t Mandag");
                        break;
                    case 2:
                        Console.WriteLine("\n\t Tirsdag");
                        break;
                    case 3:
                        Console.WriteLine("\n\t Onsdag");
                        break;
                    case 4:
                        Console.WriteLine("\n\t Torsdag");
                        break;
                    case 5:
                        Console.WriteLine("\n\t Fredag");
                        break;
                    case 6:
                        Console.WriteLine("\n\t Lørdag");
                        break;
                    case 7:
                        Console.WriteLine("\n\t Søndag");
                        break;

                    default:
                        if (dagnr !=0)
                        {
                            Console.WriteLine("\n\t Ugyldig");  
                        }              
                        break;
                }
            } while (dagnr != 0);
           // Console.ReadKey();
        }
    }
}
