﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopEx
{

    class Program
    {
        static void Main(string[] args)
        {
            ForLoopClass fc = new ForLoopClass();
           fc.ForLoopMethod();
            //fc.ForLoopStaticMethod();  static method can't be accessed through object
            ForLoopClass.ForLoopStaticMethod();
            //ForLoopClass.ForLoopMethod(); // non-static methods can't be accessed through class name
            //Console cn = new Console(); 
            Console.ReadKey();
        }
    }

}
