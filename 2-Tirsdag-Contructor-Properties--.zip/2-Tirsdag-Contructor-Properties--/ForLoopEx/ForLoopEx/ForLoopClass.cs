﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopEx
{
    public class ForLoopClass
    {
        public void ForLoopMethod()
        {
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("\n\t "+i);
            }
        }
        public static void ForLoopStaticMethod()
        {
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("\n\t " + i);
            }
        }
    }
}
