﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThisKeyWordEx
{
    public class Customer
    {
        int AcNo; string Name; double Balance;  int FoneNr;      
        public Customer()
        {
            Console.WriteLine("\n\t default Constructor");
        }

        public Customer(int AcNo, string Name, double Balance) :this()
        {
            this.AcNo = AcNo;
            this.Name = Name;
            this.Balance = Balance;
        }

        public Customer(int AcNo, string Name, double Balance, int FoneNr):this(AcNo, Name, Balance)
        {
            //this.AcNo = AcNo;
            //this.Name = Name;
            //this.Balance = Balance;
            this.FoneNr = FoneNr;
        }

        public void Saldo()
        {
            Console.WriteLine($"\n\t Acc = {AcNo}\tName = {Name}" +
                $"\t Balance = {Balance}\t Tlf = {FoneNr}");
        }
        public void Deposit(double amount)
        {
            //Balance = Balance + amount;
            Balance += amount;
        }

        public void WithDraw(double amount)
        {
            Balance -= amount;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer(555, "RigeKunde", 424245, 11111111);
            c.Saldo();
            Console.ReadKey();
        }
    }
}
