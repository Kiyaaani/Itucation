﻿using System;

using System.Data.SqlTypes;



namespace StatusFinder
{
    public class StatusFinderClass
    {
        public static SqlString StatusFinderMethod(int x)
        {
            switch (x)
            {
                case 0: return "Part Time";
                case 1: return "Full Time";
                case 2: return "CFO ";
                case 3: return "CEO ";
                case 4: return "Team Leader";
                default: return "Unknown";
                    
            }
        }
    }
}
