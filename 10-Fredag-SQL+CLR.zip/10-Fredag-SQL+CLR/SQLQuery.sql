--use MyDatabase
--go
--Create Database TestDB
--Create Table Customers
--(
-- Id int primary key identity,
-- Name nvarchar(50) not null,
-- City nvarchar(50) default 'Copenhagen'
--);
--Insert into dbo.Customers(Name)
--values('Ib'),('Ove'),('Ole'),('Mia'),('Kim')
--------------------------------------------
--Select * from dbo.Customers

--Insert into dbo.Customers(Name,City)
--values('XI','Kashgar'),('Vladimir','Moscow'),('Mark','London')
------------------------------------------------
Create table Products(
	pId int primary key identity,
	pName nvarchar(50),
	Price money default 1000
);
-------------------------
Insert [dbo].[Products] ([pName], [Price]) 
values('TV',6666),
('Phone',4324.99),
('Pizza',150.99)
-------------------------------------
Insert [dbo].[Products] ([pName]) 
values('KaffeMaskine'),
('PC'),
('Shawarma')
---------------------------------------
Create table Orders(
oId int primary key identity,
cId int Foreign key references dbo.Customers(Id),
pId int Foreign key references dbo.Products(pId),
Qty int default 1,
OrderDate date default current_timestamp
);
----------------------------------------
Insert [dbo].[Orders]( [cId], [pId], [Qty])
values(3,4,2), (1,3,1),(4,2,5),(5,1,4),(5,3,3)
-------------
Insert [dbo].[Orders]( [cId], [pId])
values(1,1), (2,2),(3,3),(4,4),(5,5)
----------------------------------------
select * from dbo.Orders
--------------------------------------------
Select c.Name,c.City, p.pName, 
		(p.price * o.Qty) as Amount,
		((p.price * o.Qty)-(p.price * o.Qty/10)) as tilbudPrice,
		o.Qty, o.OrderDate 
From dbo.Orders as o
join dbo.Customers c
--on dbo.Orders.cId = dbo.Customers.Id
on o.cId = c.Id
join dbo.Products p
on o.pId = p.pId
where c.City='Copenhagen'
order by p.pName
