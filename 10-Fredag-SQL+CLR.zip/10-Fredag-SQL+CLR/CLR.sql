use MyDatabase
go
Create table Departments
(
dId int primary key identity,
dName nvarchar(45)
);
Create table Employees(
eId int primary key identity,
FirstName nvarchar(50),
LastName nvarchar(50),
Salary money default 25000,
EmpStatus int not null,
dId int foreign key references dbo.Departments(dId)
);

--------------------------
insert [dbo].[Departments] (dName)
values ('IT'), ('HR'),('FI'),('Sales'),('Training')
----------------------
insert [dbo].[Employees]( [FirstName], [LastName], [EmpStatus], [dId])
values ('Peter','Petersen',2,1),
	('Mark','Marksen',0,1),('Ole','Olsen',1,1),
	('Ib','Ibsen',3,2),('Ove','Pedersen',4,4),
	('Kim','Pedersen',1,4),
	('Bo','Olsen',1,3),
	('Tom','Petersen',1,5),
	('Hans','Hansen',0,5),('John','Olsen',1,4),
	('Svend','Ibsen',1,3),('Mikkel','Pedersen',4,4),
	('K�re','Pedersen',1,3),
	('S�ren','S�rensen',1,3)
	---------------------------
	select * from [dbo].[Employees]
	------------------------------------------
	sp_Configure 'show advanced options', 1
	go
	reconfigure 
	--------------------------------------
	sp_Configure 'clr strict security', 0
	go
	reconfigure
	----------------------------------------
	sp_Configure 'clr enabled', 1
	go
	reconfigure
	--------------------------------------------
	-- Create Assembly in SQL SERVER
	-----------------------------------------
	Create function StatusFinderFunction(@x int)
	returns nvarchar(50)
	as
	External Name [StatusFinder].[StatusFinder.StatusFinderClass]
					.[StatusFinderMethod] 
	-- assembly.[namespace.Class].methodName
	-- Namespace and Class must be be in one bracket
	----------------------------------------------------------
	Select e.FirstName, e.LastName, e.Salary,
	[dbo].[StatusFinderFunction](e.EmpStatus) as Status, d.dName
	from [dbo].[Employees] e
	join [dbo].[Departments] d
	on e.dId = d.dId;