﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadingDemo
{
    class Program
    {
        [ThreadStatic]
        static int x = 0;
        const int sec = 1000;
        static void FunctionOne()
        {
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("\n\t ---> Func One \t"+i);
                Thread.Sleep(sec);
            }
        }
        static void FunctionTwo()
        { 
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("\n\t  Func Two <---\t " + i);
                Thread.Sleep(sec);
            }
        }
        static void ParaFunc(object obj)
        {
            for (int i = 0; i <(int)obj; i++)
            {
                Console.WriteLine("\n\t  Para Function \t " + i);
                Thread.Sleep(1000);
            }
        }
        
        static void Main(string[] args)
        {
            //FunctionOne();
            //FunctionTwo();
            //Thread Thr1 = new Thread(new ThreadStart(FunctionOne));
            //Thread Thr11 = new Thread(FunctionOne);
            //Thr1.Start();
            //Thr1.IsBackground = true;
            //Thread Thr2 = new Thread(FunctionTwo);
            //Thr2.Start();
            //Console.WriteLine("\n\t Main thread finished Job");
            //Thr1.Join();
            //----------Parameterized Thread----------------------
            //Thread TrdP = new Thread(new ParameterizedThreadStart(ParaFunc));
            //TrdP.Start(15);
            //Console.WriteLine("\n\t Main thread finished Job");
            //-----------Stopping Thread--------------------------------
            //bool DoNotListen = true;
            //Thread T = new Thread(new ThreadStart(
            //    () =>
            //    {
            //        while (DoNotListen)
            //        {
            //            Console.WriteLine("\n\t Never Stop and don't listen anyone");
            //            Thread.Sleep(1000);
            //        }
            //    }
            //    ));
            //T.Start();
            //Console.WriteLine("\n\t press any key to STOP");
            //Console.ReadKey();
            ////DoNotListen = false;
            //T.Suspend();
            ////T.Abort();
            //Console.ReadKey();
            //T.Resume();
            //-------------------Thread Static-----------------
            Thread T1 = new Thread(new ThreadStart(
                () =>
                {
                    for (int i = 0; i < 11; i++)
                    {
                        x++;
                        Console.WriteLine("\n\t Thread 1 ---> \t"+ x);
                        Thread.Sleep(sec);
                    }
                }
                ));
            T1.Start();
            Thread T2 = new Thread(new ThreadStart(
                () =>
                {
                    for (int i = 0; i < 11; i++)
                    {
                        x++;
                        Console.WriteLine("\n\t" + x +"\t <--- Thread 2");
                        Thread.Sleep(sec);
                    }
                }
                ));
            T2.Start();
        }
    }
}
