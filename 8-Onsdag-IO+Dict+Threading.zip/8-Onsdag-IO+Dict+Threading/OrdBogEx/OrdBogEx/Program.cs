﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdBogEx
{
    class Program
    {
        static void Main(string[] args)
        {
            MinOrdBog<string, string> Hilsen = new MinOrdBog<string, string>("Hej", "Med Dig");
            //Hilsen.Info();
            MinOrdBog<int, string> Regning = new MinOrdBog<int, string>(3000, "skal betales");
            //Regning.Info();
            MinOrdBog<int, string>[] Kurser = new MinOrdBog<int, string>[]
                {
                 new MinOrdBog<int, string>(480, "HTML-CSS-JavaScript"),
                  new MinOrdBog<int, string>(483, "C# - Server Side Code"),
                   new MinOrdBog<int, string>(486, "ASP.NET MVC")
                };
            //foreach (var Kursus in Kurser)
            //{
            //    Kursus.Info();
            //}
            //-----------------------------------------------
            MinOrdBog<int, Customer>[] KundeRang = new MinOrdBog<int, Customer>[]
                {
                new MinOrdBog<int, Customer>(1, new Customer(){Id=1, Name="Mark", Land=Country.Danmark }),
                new MinOrdBog<int, Customer>(3, new Customer(){Id=2, Name="Mikkel", Land=Country.Norge }),
                new MinOrdBog<int, Customer>(5, new Customer(){Id=3, Name="Maria", Land=Country.Sverige }),
                new MinOrdBog<int, Customer>(4, new Customer(){Id=4, Name="Mohsin", Land=Country.Danmark }),
                new MinOrdBog<int, Customer>(2, new Customer(){Id=5, Name="Mia", Land=Country.Sverige })
                };
            foreach (var par in KundeRang)
            {
                Console.WriteLine($"\n\t Rang = {par.Key}\t Navn = {par.Value.Name}\t" +
                    $"Land = {par.Value.Land}");
            }
            Console.WriteLine("\n\t Kunder fra Danmark -->\t"+
                                KundeRang.Count(k=> k.Value.Land==Country.Danmark));

            //-------------InBuilt --Dictionary list---------------------------
            Dictionary<int, Customer> Kunder = new Dictionary<int, Customer>();

            Kunder.Add(5, new Customer() {Id=11, Name="Kim", Land=Country.Norge });
            Kunder.Add(6, new Customer() { Id = 12, Name = "XI", Land = Country.Danmark });
            Kunder.Add(7, new Customer() { Id = 13, Name = "Putin", Land = Country.Danmark });
            foreach (var par in Kunder)
            {
                Console.WriteLine($"\n\t Rang = {par.Key}\t Navn = {par.Value.Name}\t" +
                    $"Land = {par.Value.Land}");
            }
            Console.ReadKey();
        }
    }
}
