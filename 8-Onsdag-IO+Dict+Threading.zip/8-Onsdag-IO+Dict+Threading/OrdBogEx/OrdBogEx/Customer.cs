﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdBogEx
{
    public enum Country
    {
        Danmark,
        Sverige,
        Norge
    }
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Country Land { get; set; }
    }
}
