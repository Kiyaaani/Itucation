﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdBogEx
{
    public class MinOrdBog<Nøgle, Værdi>
    {
        public Nøgle Key { get; set; }
        public Værdi Value { get; set; }

        public MinOrdBog(Nøgle k, Værdi v)
        {
            Key = k;
            Value = v;
        }
        public void Info()
        {
            Console.WriteLine($"\n\t {Key}\t {Value}");
        }
    }
}
