﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //DirectoryInfo CurrentDir = new DirectoryInfo(".");
            //Console.WriteLine("\n\t" +CurrentDir);
            //Console.WriteLine("\n\t" + CurrentDir.Name);
            //Console.WriteLine("\n\t" + CurrentDir.FullName);
            //Console.WriteLine("\n\t" + CurrentDir.Parent);
            //Console.WriteLine("\n\t" + CurrentDir.CreationTime);
            //Console.WriteLine("\n\t" + CurrentDir.CreationTimeUtc);
            //Console.WriteLine("\n\t" + CurrentDir.Attributes);
            //------------------------------------------------
            //DirectoryInfo MyDir = new DirectoryInfo(@"C:\Users\MyFolder\TEST");
            //MyDir.Create();
            //Console.WriteLine("\n\t" + MyDir.Name);
            //Console.WriteLine("\n\t" + MyDir.FullName);
            //Console.WriteLine("\n\t" + MyDir.Parent);
            //Console.WriteLine("\n\t" + MyDir.CreationTime);

            //------------------File ---Read---Write----------------
            string[] byer = {"Copenhagen","Viby", "Valby", "Rødby","Malmo","Oslo" };
            string MyFileWithPath = @"C:\Users\MyFolder\TEST\MyTextFile.txt";
            string MyFileWithPath2 = "C:\\Users\\MyFolder\\TEST\\MyTextFile.txt";
            //File.WriteAllLines(MyFileWithPath, byer); // Creates File and writes data
            File.AppendAllLines(MyFileWithPath, byer);
            foreach (var by in File.ReadAllLines(MyFileWithPath))
            {
                Console.WriteLine("\n\t"+by);
            }
            Console.ReadKey();
        }
    }
}
