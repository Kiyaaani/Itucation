﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListEx
{
   public class LinkedLst
    {
        Node head; 
        int count;
        public int Count { get => this.count; }
        //public bool Empty{get { return this.count == 0; } }
        public bool Empty { get => this.count == 0; }
        public LinkedLst()
        {
            this.head = null;  
            this.count = 0;
        }
        public void Add(int index, object data)
        {
            if (index<0)
            {
                throw new ArgumentOutOfRangeException("Er du sikkert? index= "+index);

            }
            if (index>count)
            {
                index = count;
            }
            Node current = this.head;
            if (this.Empty || index==0)
            {
                this.head = new Node(data, this.head);
            }
            else
            {
                for (int i = 0; i < index-1; i++)
                {
                    current = current.Next;
                }
                current.Next = new Node(data, current.Next);
            }
            count++;
        }
        public void Add(object data)
        {
            Add(count, data);
        }

        public void Udskrive()
        {
            Node current = this.head;
            while (current !=null)
            {
                Console.WriteLine("\n\t"+current.Data);
                current = current.Next;
            }
        }
    }
}
