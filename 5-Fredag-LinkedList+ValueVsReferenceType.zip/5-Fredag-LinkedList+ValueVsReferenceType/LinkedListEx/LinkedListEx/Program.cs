﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListEx
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedLst lst = new LinkedLst();
            lst.Add("AAAAAAAA");
            lst.Add("BBBBBBBB");

            lst.Add("CCCCCCCC");
            lst.Add("DDDDDDDD");
            lst.Add(666666666);
            lst.Add(2, "ZZZZZZZZZZ");
            lst.Udskrive();
            //-----------------Inbuilt List------------------

            LinkedList<int> inbuiltList = new LinkedList<int>();
            var Node1 =inbuiltList.AddFirst(11111111);
            var Node3= inbuiltList.AddAfter(Node1, 333333333);
            inbuiltList.AddBefore(Node3, 7777777);
            inbuiltList.AddLast(99999999);
            inbuiltList.RemoveFirst();
            foreach (var item in inbuiltList)
            {
                Console.WriteLine("\n\t"+item);
            }
            Console.ReadKey();
        }
    }
}
