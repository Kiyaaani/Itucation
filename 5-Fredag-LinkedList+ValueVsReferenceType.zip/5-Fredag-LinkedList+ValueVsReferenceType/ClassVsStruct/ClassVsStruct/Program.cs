﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassVsStruct
{
    class ClassCustomer
    {
        int id; string name;
        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }

        public ClassCustomer()
        {
            Console.WriteLine("\n\t Default Constructor");
        }

        public ClassCustomer(int id, string name)
        {
            this.id = id;
            this.name = name;
        }

        public void Info()
        {
            Console.WriteLine($"Id = \t {this.id}\t Name = {this.name}");
        }
    }
    struct StructCustomer
    {
        int id; string name;
        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }

        //public StructCustomer()
        //{
        //    Console.WriteLine("\n\t Default Constructor");
        //}

        public StructCustomer(int id, string name)
        {
            this.id = id;
            this.name = name;
        }

        public void Info()
        {
            Console.WriteLine($"\n\tId = \t {this.id}\t Name = {this.name}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n\t --------CLASS---------------------\n");
            ClassCustomer c = new ClassCustomer();
            c.Id = 1; c.Name = "Ib Ibsen";
            c.Info();

            ModifyClassCustomer(c);
            c.Info();

            Console.WriteLine("\n\t --------STRUCT---------------------\n");
            StructCustomer sc = new StructCustomer();
            sc.Id = 2; sc.Name = "Peter Petersen";
            sc.Info();

            ModifyStructCustomer(sc);
            sc.Info();

            Console.ReadKey();
        }
        static void ModifyClassCustomer(ClassCustomer classObject)
        {
            classObject.Id += 100;
            classObject.Name = "new Name Ole Olsen";
            Console.WriteLine($"\n\t data within Modify-Methed\t" +
                $"Id = \t {classObject.Id}\t Name = {classObject.Name}");
        }
        static void ModifyStructCustomer(StructCustomer StructObject)
        {
            StructObject.Id += 100;
            StructObject.Name = "new Name Mikkel";
            Console.WriteLine($"\n\t data within Modify-Methed\t" +
               $"Id = \t {StructObject.Id}\t Name = {StructObject.Name}");
        }
    }
}
