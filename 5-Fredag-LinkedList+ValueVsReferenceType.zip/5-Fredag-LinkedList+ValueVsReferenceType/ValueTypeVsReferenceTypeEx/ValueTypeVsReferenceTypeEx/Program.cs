﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueTypeVsReferenceTypeEx
{
    class Person
    {
        int id;
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5;
            int z = x;
            Console.WriteLine($"\n\t x = {x} \t z= {z}");
            z = 7;
            Console.WriteLine($"\n\t x = {x} \t z= {z}");
            //--------------------------
            Person p1 = new Person();
            p1.Id = 1; p1.Name = "Mark";

            Person p2 = new Person();
            p2.Id = 1; p2.Name = "Mark";

            if (p1==p2)
            {
                Console.WriteLine("\n\t Yes Equal");
            }
            else
            {
                Console.WriteLine("\n\t Not Equal");
            }
            Person p3 = p1;
            p3 = p2;
            p3.Name = "Peter";
            if (p1 == p3)
            {
                Console.WriteLine($"\n\t Yes Equal p1.Name = {p1.Name}\tp3.Name = {p3.Name}");
            }
            else
            {
                Console.WriteLine("\n\t Not Equal");
            }
            Console.ReadKey();
        }
    }
}
