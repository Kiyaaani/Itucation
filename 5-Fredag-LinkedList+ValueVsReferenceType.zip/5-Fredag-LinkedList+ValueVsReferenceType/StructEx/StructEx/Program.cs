﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructEx
{
    struct Kursist
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Kursist[] Elever = new Kursist[3];
            for (int i = 0; i < Elever.Length; i++)
            {
                Console.WriteLine("\n\t Id please");
                int x;
                int.TryParse(Console.ReadLine(), out x);
                Elever[i].Id = x;

                Console.WriteLine("\n\t Name please");
                Elever[i].Name = Console.ReadLine();
            }

            Console.WriteLine("\n\t--------------------------\n");
            foreach (var Elev in Elever)
            {
                Console.WriteLine($"\n\t Id =\t{Elev.Id}\t Name =\t{Elev.Name}");
            }
            Console.ReadKey();
        }
    }
}
