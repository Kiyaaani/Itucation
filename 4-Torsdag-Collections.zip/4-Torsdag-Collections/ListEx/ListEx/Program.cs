﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListEx
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //limitation of array
            //int[] A = new int[2];
            //A[0] = 5; A[1] = 3; A[2] = 7;
            //foreach (var item in A)
            //{
            //    Console.WriteLine("\t"+item);
            //}
            List<int> lst = new List<int>(1); //(3);
            //lst.Add(22); 
            //lst.Add(332); lst.Add(252);
            //lst.Add(27); lst.Add(29);

            //foreach (var item in lst)
            //{
            //    Console.WriteLine("\n\t"+item);
            //}
            //Console.WriteLine("\n\t ---- initial Capacity---\t"+lst.Capacity);

            for (int i = 0; i < 35; i++)
            {
                Console.WriteLine("\n\t ---- initial Capacity---\t" + lst.Capacity);
                Console.WriteLine("\n\t ---- Listl Count---\t" + lst.Count);
                lst.Add(i);
                Console.WriteLine("\n\t--------------------------------------\n");
            }
            lst.TrimExcess();
            Console.WriteLine("\n\t ---- initial Capacity---\t" + lst.Capacity);
            Console.WriteLine("\n\t ---- Listl Count---\t" + lst.Count);
            //---------------------------------------------------------------

            List<Customer> lc = new List<Customer>();
            lc.Add(new Customer() { Id = 1, Name = "Ib" });
            lc.Add(new Customer() { Id = 2, Name = "Ole" });
            lc.Add(new Customer() { Id = 3, Name = "Ove" });

            foreach (Customer kunde in lc)
            {
                Console.WriteLine($"\n\t {kunde.Id} \t {kunde.Name}");
            }

            Console.ReadKey();
        }
    }
}
