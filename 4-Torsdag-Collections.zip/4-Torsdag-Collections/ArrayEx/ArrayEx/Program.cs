﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayEx
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Customer(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] A1 = new int[] { 5, 6, 7, 8, 9 };
            //int[] A = new int[4];
            //A[0] = 33; A[1] = 55 + A[0];
            //A[2] = 123 - A[1];
            //Console.WriteLine("\n\t 4th value please");
            ////A[3]=int.Parse(Console.ReadLine());
            //int.TryParse(Console.ReadLine(), out A[3]);

            //WriteInConsole(A);
            //Array.Sort(A);
            //WriteInConsole(A);
            //Array.Reverse(A);
            //WriteInConsole(A);
            Customer[] kunder = new Customer[3];
            kunder[0] = new Customer(11, "Mikkel");
            kunder[1] = new Customer(22, "Marie");
            kunder[2] = new Customer(33, "Mark");

            foreach (Customer kunde in kunder)
            {
                //Console.WriteLine("\n\t" + kunde);
                Console.WriteLine($"\n\t Id = {kunde.Id}\t Name = {kunde.Name}\n");
            }

            Console.ReadKey();
        }

        private static void WriteInConsole(int[] A)
        {
            Console.WriteLine("\n\t ----Values in Array A----");
            foreach (int a in A)
            {
                //Console.WriteLine("\n\t "+a);
                Console.WriteLine($"\n\t  {a}" );
            }
        }
    }
}
