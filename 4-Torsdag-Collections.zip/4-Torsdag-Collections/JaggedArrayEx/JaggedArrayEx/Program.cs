﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayEx
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] JA = new int[4][];
            JA[0] = new int[3];
            JA[0][0] = 44;
            JA[0][1] = 34;
            JA[0][2] = 54;

            JA[1] = new int[5];
            JA[1][0] = 94;
            JA[1][1] = 74;
            JA[1][2] = 24;        
            JA[1][3] = 14;
            JA[1][4] = 31;
            JA[2] = new int[] { 100 };
            JA[3] = new int[] {55,22,33,11,55,44,77,88,66 };

            for (int i = 0; i < JA.Length; i++)
            {
                Console.WriteLine("\n");
                for (int j = 0; j < JA[i].Length; j++)
                {
                    Console.Write(JA[i][j]+"\t");
                }
            }
            Console.ReadKey();
        }
    }
}
