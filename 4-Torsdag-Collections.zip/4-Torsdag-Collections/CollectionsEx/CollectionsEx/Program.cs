﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace CollectionsEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stack s = new Stack();
            //s.Push(22); s.Push("X-box");
            //s.Push(543.767);
            //foreach (var item in s)
            //{
            //    Console.WriteLine("\n\t"+item);
            //}
            //Console.WriteLine("\n------Values after pop()------");
            //s.Pop();
            //foreach (var item in s)
            //{
            //    Console.WriteLine("\n\t" + item);
            //}
            ////-----------------------------------------
            //Queue q = new Queue();
            //q.Enqueue(33); q.Enqueue("Play-Station");
            //q.Enqueue(55.5);

            //foreach (var item in q)
            //{
            //    Console.WriteLine("\n\t" + item);
            //}

            //q.Dequeue();

            //foreach (var item in q)
            //{
            //    Console.WriteLine("\n\t" + item);
            //}
            //-------------------------------------------------------------------------

            Stack<int> s = new Stack<int>();
            s.Push(34);

            Queue<string> byer = new Queue<string>();
            byer.Enqueue("Valby");

            Stack<object> SO = new Stack<object>();
            SO.Push(5454); SO.Push("SomeString");

            Console.ReadKey();
        }

    }
}
