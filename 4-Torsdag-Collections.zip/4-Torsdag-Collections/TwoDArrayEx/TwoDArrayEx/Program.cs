﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDArrayEx
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3, 4] 
            {
                {5,3,7,6 },
                {9,7,6,1 },
                { 8,9,7,4}
            };
            //foreach (var item in matrix)
            //{
            //    Console.WriteLine("\n\t"+item);
            //}

            for (int row = 0; row < 3; row++)
            {
                Console.WriteLine("\n");
                for (int col = 0; col < 4; col++)
                {
                    //Console.WriteLine($"\t{matrix[row,col]}");
                    Console.Write($"\t{matrix[row, col]}");
                }
               
            }

            Console.ReadKey();
        }
    }
}
