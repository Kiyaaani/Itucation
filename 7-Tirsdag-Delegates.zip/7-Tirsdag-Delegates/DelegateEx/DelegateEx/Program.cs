﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEx
{
    delegate void Test(string msg);
    class Program
    {
        static void Show(string besked)
        {
            Console.WriteLine("\n\t Show Method --> \t"+besked);
        }
        static void Vise(string besked)
        {
            Console.WriteLine("\n\t Vise Method --> \t" + besked);
        }
        static void Display(string besked)
        {
            Console.WriteLine("\n\t Display Method --> \t" + besked);
        }
        static void View(string besked)
        {
            Console.WriteLine("\n\t View Method --> \t" + besked);
        }
        static void Print(string besked)
        {
            Console.WriteLine("\n\t Print Method --> \t" + besked);
        }
        static void Info(string besked)
        {
            Console.WriteLine("\n\t Info Method --> \t" + besked);
        }
        static void Main(string[] args)
        {
            Test t;// = new Test(Show);
                   //t += new Test(Display);
            //t = Show;
            //t += Display;
            //t += Vise;
            //t += View;
            //t += Print;
            //t += Info;
            //t("Represented by this delegate");
            //t -= Display;
            //t("Represented by this delegate but not Display Method");
            Console.ReadKey();
        }
    }
}
