﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InBuiltDelegatesDemo
{
    delegate int CalcRep(int x);
    class Program
    {
        static int Kvadrat(int x)
        {
            return x * x;
        }
        static int Kube(int x)
        {
            return x * x * x;
        }
        static void Main(string[] args)
        {
            //CalcRep cr; = new CalcRep(Kvadrat);
            //CalcRep cr;
            //cr = Kvadrat;
            //Console.WriteLine($"\n\t {cr(5)}\t {cr.Invoke(6)}");

            //----------More than one method--------
            //cr += Kube;
            //Console.WriteLine($"\n\t {cr(5)}\t {cr.Invoke(6)}");
            //fungerer ikke hvis der er flere retunerede værdier
            //If you want to invoke different methods with different arguments, use following 
            //Console.WriteLine(
            //    $"\n\t {cr.GetInvocationList()[0].DynamicInvoke(5)}\t" +
            //    $" {cr.GetInvocationList()[1].DynamicInvoke(6)}");
            //If you want to invoke different methods with same arguments, use following
            //IEnumerable<int> Result = cr.GetInvocationList()
            //                            .Select(m => (int)m.DynamicInvoke(6));

            //foreach (var item in Result)
            //{
            //    Console.WriteLine("\n\t"+item);
            //}
            //------------------Anonymous function---------------------------------------------

            //CalcRep cr = new CalcRep(delegate (int x)
            //{
            //    return x * x;
            //});
            //Console.WriteLine("\n\t"+cr(9));
            //---------------Lambda Expression---------------------------
            //CalcRep cr2 = z => z * z;
            //Console.WriteLine("\n\t" + cr2(9));
            //-------FUNC-------+-Lambda Expression-----------------------
            //Func<int, int> fcr = k => k * k;
            //Console.WriteLine("\n\t" + fcr(9));

            //Func<int, string> fcr2 = k => (k * k).ToString();
            //Console.WriteLine("\n\t" + fcr2(8));
            //--------Action---------------------------------------------
            //Action<int> MyAction = doIt => Console.WriteLine("\n\t"+doIt);
            //int x = 7;
            //MyAction(x);
            //Action<string> strAction = s => Console.WriteLine("\n\t" + s);
            //strAction("String --> " + x);
            //---------Predicate------------Always returns boolean--------------
            Predicate<int> kanJegStemme = alder => alder >= 18;
            Console.WriteLine("\n\t jeg kan stemme "+kanJegStemme(19));

            Predicate<string> LessThan7 = s => s.Length < 7;
            List<string> byer = new List<string>();
            byer.Add("Copenhagen"); byer.Add("Malmo");
            byer.Add("Kazan"); byer.Add("Alaan Bataar");
            byer.Add("Oslo"); byer.Add("Valby");
            byer.Add("Berlin"); byer.Add("Turku");

            Console.WriteLine("\n\t"+byer.Find(LessThan7));
            IEnumerable<string> SmallNameCities = byer.FindAll(LessThan7);
            foreach (var City in SmallNameCities)
            {
                Console.WriteLine("\n\t"+City);
            }

            Console.ReadKey();
        }
    }
}
