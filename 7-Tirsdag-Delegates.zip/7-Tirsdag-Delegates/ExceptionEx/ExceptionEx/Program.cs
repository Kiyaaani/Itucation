﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionEx
{
    class Program
    {
        static void Main(string[] args)
        {
            string MyString = "5";
            //string MyString = "Something Else";
            //string MyString = null;
            try
            {
                int x = int.Parse(MyString);
                Console.WriteLine("\n\t" + x);
            }
            //catch (FormatException bla)
            //{
            //    Console.WriteLine("\n\t Ugyldigt Format\t"+bla.Message);
            //}
            //catch (ArgumentNullException bla)
            //{
            //    Console.WriteLine("\n\t Ugyldigt Format\t" + bla.Message);
            //}
            catch (Exception e)
            {
                Console.WriteLine("\n\t Ugyldigt Format\t" + e.Message);
            }
            finally
            {
                Console.WriteLine("\n\t Finally Always Runs");
            }
            Console.ReadKey();
        }
    }
}
