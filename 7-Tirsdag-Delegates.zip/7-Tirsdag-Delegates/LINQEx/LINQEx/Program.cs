﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace LINQEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] A = { 45, 55, 46, 88, 77, 66, 55, 44, 33, 88, 99, 78, 98, 97, 68 };
            //IEnumerable<int> QueryResult = from x in A
            //                               where x > 50
            //                               orderby x descending
            //                               select x;
            //foreach (var item in QueryResult)
            //{
            //    Console.WriteLine("\n\t"+item);
            //}
            List<int> lst = new List<int> { 45, 55, 46, 88, 77, 66, 55, 44, 33, 88, 99, 78, 98, 97, 68 };
            //IEnumerable<int> QueryResult = from x in lst
            //                               where x < 50
            //                               orderby x descending
            //                               select x;

            //foreach (var item in QueryResult)
            //{
            //    Console.WriteLine("\n\t" + item);
            //}

            //int OneValue = from x in lst       // fejl
            //                               where x == 55
            //                               select x;

            var OneValue = (from x in lst
                           where x == 55
                           select x).First();
            //foreach (var item in OneValue)
            //{
            //    Console.WriteLine("\n\t" + item);
            //}
            //Console.WriteLine("\n\t"+OneValue);
            //--------------------------XML---------------------------
            XElement EmpXML = XElement.Load("employees.xml");
            var empXMLResult = from emp in EmpXML.Descendants("Employee")
                               orderby emp.Element("FirstName").Value
                               select emp;

            foreach (var emp in empXMLResult)
            {
                //Console.WriteLine("\n\t" + item);
                Console.WriteLine($"\n\t Employee --> {emp.Element("FirstName").Value}" +
                    $" {emp.Element("LastName").Value}" +
                    $"\t Lives in {emp.Element("Location").Value}");
            }
            Console.ReadKey();
        }
    }
}
